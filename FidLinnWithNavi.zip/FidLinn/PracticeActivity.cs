﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace FidLinn
{
    [Activity(Label = "PracticeActivity")]
    public class PracticeActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.Practice);

            Button tuningButton = FindViewById<Button>(Resource.Id.myButton1);

            Button backButton = FindViewById<Button>(Resource.Id.myButton2);

            backButton.Click += delegate { StartActivity(typeof (MainActivity)); };

        }
    }
}
